from django.db import models

# Create your models here.
class TeacherModel(models.Model):
    first=models.CharField(max_length=100)
    last=models.CharField(max_length=100)
    age=models.IntegerField()
    qualification=models.CharField(max_length=100)
    email=models.EmailField()
    phone=models.IntegerField()
