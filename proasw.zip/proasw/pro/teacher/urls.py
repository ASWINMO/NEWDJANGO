from django.urls import path
from .views import *

urlpatterns = [
    path('addmark/',AddMarkView.as_view(),name="addm"),
    path('addst/',AddStudentMForm.as_view(),name="addstudent"),
    path('view/',ViewStudentView.as_view(),name="vie"),
    path('delstudent/<int:ssid>',DeleteStudentView.as_view(),name="delstu"),
    path('editstudent/<int:sid>',EditStudentMView.as_view(),name="editstu")



]
