from django.shortcuts import render,redirect
from django.views.generic import View
from .forms import *
from django.http import HttpResponse
from django.contrib import messages
from.models import StudentModel
from django.utils.decorators import method_decorator

def signin_required(fun):
    def wrapper(request,*args,**kwargs):
        if request.user.is_authenticated:
            return fun(request,*args,**kwargs)
        else:
            return redirect("log")
    return wrapper




# Create your views here.
@method_decorator(signin_required,name='dispatch')
class AddMarkView(View):
    def get(self,request,*args,**kwargs):
        f=AddMarkForm()
        return render(request,"addmark.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=AddMarkForm(data=request.POST)
        if form_data.is_valid(): 
            num1=form_data.cleaned_data.get("num1")
            num2=form_data.cleaned_data.get("num2")
            num3=form_data.cleaned_data.get("num3")
            num4=form_data.cleaned_data.get("num4")
            num5=form_data.cleaned_data.get("num5")
            mark=int(num1)+int(num2)+int(num3)+int(num4)+int(num5)
            return render(request,"addmark.html",{"res":mark})
        else:
            return render(request,"addmark.html",{"form":form_data})


# class AddStudentView(View):
#     def get(self,request,*args,**kwargs):
#         f=StudentForm()
#         return render(request,"addstu.html",{"form":f})
#     def post(self,request,*args,**kwargs):
#         form_data=StudentForm(data=request.POST)
#         if form_data.is_valid():
#             fname=(form_data.cleaned_data.get("first_name"))
#             lname=(form_data.cleaned_data.get("last_name"))
#             age=(form_data.cleaned_data.get("age"))
#             address=(form_data.cleaned_data.get("address"))
#             email=(form_data.cleaned_data.get("email"))
#             phone=(form_data.cleaned_data.get("phone"))
#             StudentModel.objects.create(first=fname,last=lname,age=age,address=address,email=email,phone=phone)
#             messages.success(request,"Student added successfully!!")
#             return redirect("h")
#         else:
#             messages.success(request,"Student adding faild!!")
#             return render(request,"addstu.html",{"form":form_data})

@method_decorator(signin_required,name='dispatch')
class AddStudentMForm(View):
    def get(self,request,*args,**kwargs):
        f=StudentMForm()
        return render(request,"addstu.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=StudentMForm(data=request.POST,files=request.FILES)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"Student added successfully!!")
            return redirect("h")
        else:
            messages.success(request,"Student adding faild!!")
            return render(request,"addstu.html",{"form":form_data})



@method_decorator(signin_required,name='dispatch')
class ViewStudentView(View):
        def get(self,request,*args,**kwargs):
                res=StudentModel.objects.all()
                return render(request,"studentlist.html",{"data":res})


@method_decorator(signin_required,name='dispatch')
class DeleteStudentView(View):
        def get(self,request,*args,**kwargs):
            sid=kwargs.get("ssid")
            stu=StudentModel.objects.get(id=sid)
            stu.delete()
            return redirect("vie")


@method_decorator(signin_required,name='dispatch')
class DeleteStudentView(View):
        def get(self,request,*args,**kwargs):
            sid=kwargs.get("ssid")
            stu=StudentModel.objects.get(id=sid)
            stu.delete()
            return redirect("vie")

@method_decorator(signin_required,name='dispatch')
class EditStudentView(View):
        def get(self,request,*args,**kwargs):
            sid=kwargs.get("ssid")
            stu=StudentModel.objects.get(id=sid)
            stu.edit()
            return redirect("vie")

# class EditStudentView(View):
#     def get(self,request,*args,**kwargs):
#         id=kwargs.get("sid")
#         stu=StudentModel.objects.get(id=id)
#         f=StudentForm(initial={"first_name":stu.first,"last_name":stu.last,"age":stu.age,"address":stu.address,"email":stu.email,"phone":stu.phone})
#         return render(request,"editstudent.html",{"form":f})

#     def post(self,request,*args,**kwargs):
#         form_data=StudentForm(data=request.POST)
#         if form_data.is_valid():
#             fname=(form_data.cleaned_data.get("first_name"))
#             lname=(form_data.cleaned_data.get("last_name"))
#             age=(form_data.cleaned_data.get("age"))
#             address=(form_data.cleaned_data.get("address"))
#             email=(form_data.cleaned_data.get("email"))
#             phone=(form_data.cleaned_data.get("phone"))
#             id=kwargs.get("sid")
#             stu=StudentModel.objects.get(id=id)
#             stu.first=fname
#             stu.last=lname
#             stu.age=age
#             stu.address=address
#             stu.email=email
#             stu.phone=phone
#             stu.save()
#             messages.success(request,"student-Deatails Updated Successfully!!")
#             return redirect("vie")
#         else:
#             messages.error(request,"Updation Failed")
#             return render(request,"editstudent.html",{"form":form_data})
        
@method_decorator(signin_required,name='dispatch')
class EditStudentMView(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id)
        f=StudentMForm(instance=stu)
        return render(request,"editstudent.html",{"form":f})
    def post(self,request,*args,**kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id)
        form_data=StudentMForm(data=request.POST,instance=stu,files=request.FILES)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"Student added successfully!!")
            return redirect("h")
        else:
            messages.success(request,"Student adding faild!!")
            return render(request,"addstu.html",{"form":form_data})







    

















    # def post(self,request,*args,**kwargs):
    #     print(request.POST.get("first_name"))
    #     return HttpResponse("username:"+request.POST.get("first_name")+"<br>lastname:"+request.POST.get("last_name")+"<br>age:"+request.POST.get("age")+"<br>address:"+request.POST.get("address")+"<br>email:"+request.POST.get("email")+"<br>phone:"+request.POST.get("phone"))