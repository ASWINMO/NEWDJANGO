from django import forms
from.models import StudentModel

class AddMarkForm(forms.Form):
    num1=forms.IntegerField(label="enter mark of student1")
    num2=forms.IntegerField(label="enter mark of student2")
    num3=forms.IntegerField(label="enter mark of student3")
    num4=forms.IntegerField(label="enter mark of student4")
    num5=forms.IntegerField(label="enter mark of student5")
    def clean(self):
        cleaned_data=super().clean()
        num1=cleaned_data.get("num1")
        num2=cleaned_data.get("num2")
        num3=cleaned_data.get("num3")
        num4=cleaned_data.get("num4")
        num5=cleaned_data.get("num5")


        if num1<0:
            msg="Mark less than zero.invalid input"
            self.add_error("num1",msg)
        if num2<0:
            msg="Mark less than zero.invalid input"
            self.add_error("num2",msg)
        if num3<0:
            msg="Mark less than zero.invalid input"
            self.add_error("num3",msg)
        if num4<0:
            msg="Mark less than zero.invalid input"
            self.add_error("num4",msg)
        if num5<0:
            msg="Mark less than zero.invalid input"
            self.add_error("num5",msg)



        
class StudentForm(forms.Form):
    first_name=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enther first name"}))
    last_name=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enther last name"}))
    age=forms.IntegerField(widget=forms.NumberInput(attrs={"class":"form-control","placeholder":"enther your age"}))
    address=forms.CharField(max_length=500,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enther your address "}))
    email=forms.EmailField(widget=forms.EmailInput(attrs={"class":"form-control","placeholder":"enther your email"}))
    phone=forms.IntegerField(widget=forms.NumberInput(attrs={"class":"form-control","placeholder":"enther your phone number"}))
    def clean(self):
        cleaned_data=super().clean()
        fname=cleaned_data.get("first_name")
        lname=cleaned_data.get("last_name")
        age=cleaned_data.get("age")
        address=cleaned_data.get("address")
        email=cleaned_data.get("email")
        phone=str(cleaned_data.get("phone"))

        if fname==lname:
            self.add_error("last_name","first_name and last_name are same")
        if age<1:
            self.add_error("age","age is invalid")
        if len(phone)!=10:
            self.add_error("phone","digits are not 10")

class StudentMForm(forms.ModelForm):
    class Meta:
        model=StudentModel
        fields="__all__"
        widgets={
            "first":forms.TextInput(attrs={"class":"form-control","placeholder":"First Name"}),
            "last":forms.TextInput(attrs={"class":"form-control","placeholder":"last Name"}),
            "age":forms.NumberInput(attrs={"class":"form-control","placeholder":"Age"}),
            "address":forms.Textarea(attrs={"class":"form-control","placeholder":"Address"}),
            "email":forms.EmailInput(attrs={"class":"form-control","placeholder":"Email "}),
            "phone":forms.NumberInput(attrs={"class":"form-control","placeholder":"Phone"}),



            
            




        }
    def clean(self):
        cleaned_data=super().clean()
        fname=cleaned_data.get("first")
        lname=cleaned_data.get("last")
        age=cleaned_data.get("age")
        phone=str(cleaned_data.get("phone"))

        if fname==lname:
            self.add_error("last","firstname and lastname are same")
        if age<1:
            self.add_error("age","age is invalid")
        if len(phone)!=10:
            self.add_error("phone","digits are not 10")









        

        


