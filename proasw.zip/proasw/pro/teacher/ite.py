# class Myclass:
#     namee="aswin"
#     @property
#     def fun(self):
#         return "hello"

# ob=Myclass()
# print(ob.namee)
# print(ob.fun)

# def dec_fun(fun):
#     def wrapper(a,b):
#         if a>b:
#             return fun(a,b)
#         else:
#             return fun(b,a)
#     return wrapper

# @dec_fun
# def diff(a,b):
#     return a-b

# @dec_fun
# def div(a,b):
#     return a/b

# print(diff(10,20))
# print(div(10,20))


# def signin_required(fun):
#     def wrapper(self,request,*args,**kwargs):
#         if request.user.is_valid()