from django.urls import path
from .views import *

urlpatterns = [
    path('userhome/',userView.as_view(),name="uh"),
    path('profile/',ProfileView.as_view(),name="prof"),
    path('addprofile/',AddProfile.as_view(),name="addpro"),
    path('cpassword/',cpassView.as_view(),name="cpass"),
    path('edit/<int:pid>',EditProfile.as_view(),name="ed"),



    ]
